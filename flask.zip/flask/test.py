from main import db,Car,Spec

spec= Spec(color='Blue',city='Hebron',price =10000)
#car=Car(model='VW',year_man=2000,specs=[spec])

#db.session.add(car)

#db.session.commit()

'''
#print(Car.query.all())
car = Car.query.get(1)
car.specs.append(spec)
db.session.commit()
print(Car.query.all())
'''


#q= Car.query.filter(Car.model == 'Subaru').all()
q= Car.query.join(Car.specs).filter(db.or_(Spec.price >5000 , Car.model=='Subaru')).all()

print(q[0].specs[0].color)

q.Car.specs[0].