from flask import Flask,request,jsonify
from flask_sqlalchemy import SQLAlchemy
from dataclasses import dataclass

##initialize Flask
app =Flask(__name__)

#configs
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.config['JSON_SORT_KEYS']=False



##initialize db
db=SQLAlchemy(app)

###DB classes

@dataclass
class Spec(db.Model):
    color: str
    city :str
    price:int
    car_id: int
    


    id = db.Column(db.Integer,primary_key=True)
    color = db.Column(db.String(128),nullable=True)
    city =  db.Column(db.String(128),nullable=True)
    price = db.Column(db.Integer,nullable=False)
    car_id = db.Column(db.Integer,db.ForeignKey('car.id'),nullable=False)



@dataclass
class Car(db.Model):
    id: int
    model: str
    year_man:int
    specs: Spec



    id = db.Column(db.Integer,primary_key=True)
    model = db.Column(db.String(128),nullable=True)
    year_man = db.Column(db.Integer,nullable=False)
    specs = db.relationship('Spec',cascade="all,delete")





###Post Method

@app.route('/car',methods=['POST'])
def car_post():
    model = request.json['model']
    year_man=request.json['year_man']
    color=request.json['color']
    city=request.json['city']
    price=request.json['price']
    specs = Spec(color=color,city=city,price=price)
    new_car = Car(model=model,year_man=year_man,specs=[specs])
    db.session.add(new_car)
    db.session.commit()
    return jsonify(new_car)


###Get all cars
@app.route('/allcars',methods=['GET'])
def all_cars():
    all_cars= Car.query.all()
    return jsonify(all_cars)

###Get car by ID
@app.route('/car/<id>',methods=['GET'])
def car(id):
    car = Car.query.get(id)
    return jsonify(car)

### Change Car
@app.route('/car/<id>',methods=['PUT'])
def upd_car(id):
    car = Car.query.get(id)
    car.model = request.json['model']
    car.year_man=request.json['year_man']    
    db.session.commit()
    return  jsonify(car)


###Delete
@app.route('/car/<id>',methods=['DELETE'])
def del_car(id):
    car = Car.query.get(id)
    db.session.delete(car)
    db.session.commit()
    return  jsonify(car)



if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)